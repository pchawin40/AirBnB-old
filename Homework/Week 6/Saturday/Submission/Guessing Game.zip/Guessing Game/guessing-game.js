debugger
/* 
* Intro:
* Begin by creating a folder called guessing-game-project. Open the folder in VSCode. Inside of that folder
* create a guessing - game.js file.This is the file where we will do all of the coding.
*
* askGuess:
* Since we will be taking user input during gameplay, we'll need to do some standard setup for Node's readline module. 
* Reference the readline docs to create an interface for input and output that we will use. To stay organized, we recommend that 
* you import the module and create the interface at the tippy top of your file.
*
*
* Update as of 02.23.22 for Saturday Homework - Guessing Game Project pt. 2
* 
* Phase II: Making it Random
* Implement logic to allow the secretNumber to be chosen at random. Utilize Math#random method
*
*
* Bonus: Limiting the number of turns
* 
* With this new feature, if the player uses all of their attempts without guessing the correct number,
* they will lose the game
* 
* Implementations:
* - Limiting turns to 5: Limit player to 5 attempts. Initializing numAttempts variable in the global scope.
* Refactor askGuess method to decrement the number of remaining attempts whenever it is called. If numAttempts
* reaches 0 before the correct guess is made, end the game by printing "You Lose". 
* - Limiting turns dynamically
*/

// creating interface for input and output to be use with guessing-game
const readline = require("readline");
const interface = readline.createInterface({
  input: process.stdin,
  output: process.stdout
}); // end interface initialization

// initializing secretNumber in global scope
let secretNumber;

// global variable flag; defaulted as false
let flag = false;

// initializing numAttempts in global scope
let numAttempts;

/*
* This function accept a minimum and maximum number as arguments and return a random whole
* number between the provided minimum and maximum (inclusive)
*
* @param {number} minNum
* @param {number} maxNum
* @return {number} a random whole number between the provided minimum and maximum (inclusive)
*/
const randomInRange = (minNum, maxNum) => secretNumber = Math.floor(Math.random() * (maxNum - minNum) + minNum);

/*
* This function accept a number as an argument. It then compare the argument against the global secretNumber.
* It then does:
* - when the argument is larger that secretNumber, it print "Too high" and return false
* - when the argument is smaller than secretNumber, it print "Too low" and return false
* - when the argument is equal to secretNumber, it print "Correct!" and return true
*
* @param {number} number
* @return {boolean} true if given number is equal to secretNumber. False, if not.
*/
const checkGuess = number => {
  // if number is greater than secretNumber
  if (Number(number) > secretNumber) {
    // print "Too high"
    console.log("Too high");
    // set flag to false
    flag = false;
  // else if number is less than secretNumber
  } else if (Number(number) < secretNumber) {
    // print "Too low"
    console.log("Too low");
    // set flag to false
    flag = false;
  // else
  } else {
    // print "Correct"
    console.log("Correct");
    // set flag to true
    flag = true;
  } // end if-else statement

  // decrement numAttempts
  numAttempts--;

  // call askGuess 
  askGuess();
} // end checkGuess() function

/*
* This function use the readline module's question method to ask the user to 'Enter a guess: '. Once the user enter 
* their number, the checkGuess funciton will be called with their number as an argument and the interface
* will be closed
*
* @param {nothing}
* @return {nothing}
*/
const askGuess = () => {
  if (numAttempts === undefined) interface.question("Enter number of attempt: ", setLimitAttempt);

  // checker for checking if numAttempts is less than or equal to 0, if it is end the game and print "You Lose!"
  if (numAttempts <= 0) {
    console.log("You lose!");
    interface.close();
  } // end numAttempts conditional if statement
  // while flag is false
  else {
    if (!flag) {
      // ask user "Enter a guess: " + then send response over to checkGuess
      interface.question("Enter a guess : ", checkGuess);
    } else {
      // if flag is true:
      // print "You win!"
      console.log("You win!");
      // close interface
      interface.close();
    } // end flag conditional if statement
  }
} // end askGuess() function

/*
* This helper function sets the number of attempt for the guessing-game
*
* @param {nothing}
* @return {nothing}
*/
const setLimitAttempt = (answer) => {
  // set numAttempts to be given answer
  numAttempts = answer;
  // call askGuess() 
  askGuess();
} // end setLimitAttempt
  
/*
* This function ask the user to enter a minimum number and ask them to enter a maximum number. Ask 
* user for only after they have responded to the first question.
*
* @param {nothing}
* @return {nothing}
*/
const askRange = () => {
  // variable for storing argument to be passed into randomInRange()  
  let minNum;
  let maxNum;
  
  // ask the user to enter a minimum number
  interface.question("Enter a min number: ", _askMin)

  // cb function for setting min number
  function _askMin(answer) {
  // set user's answer to minNum
  minNum = Number(cleanNumber(answer));

  // ask "Enter a max number" and invoke askMax after receiving user's response
  interface.question("Enter a max number: ", _askMax);
  } // end askMin() function

  // cb function for setting max number
  function _askMax(answer) {
    // set user's answer to maxNum
    maxNum = Number(cleanNumber(answer));

    _confirmRange();
  } // end askMax() function

  // invoke askGuess() function
  const _confirmRange = () => {
    // after user enters min and max, print a message confirming the range
    console.log(`I'm thinking of a number between ${minNum} and ${maxNum}`);

    // set range with minNum and maxNum passed in
    randomInRange(minNum, maxNum);

    console.log("secretNumber: " + secretNumber)

    setTimeout(askGuess, 0);
  } // end nextStep() function
}; // end askRange() function

/* 
* This helper function help remove special characters (characters that are not numbers) from answer
*
* @param {string} answer
* @return {number}
*/
const cleanNumber = answer => answer.split('').filter(char => "1234567890".includes(char)).join('');

// call askRange() to begin the game
askRange();
